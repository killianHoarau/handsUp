A Pen created at CodePen.io. You can find this one at http://codepen.io/JFarrow/pen/auqHF.

 Simple QR Code Generator -enter URL and it generates a QR code to download