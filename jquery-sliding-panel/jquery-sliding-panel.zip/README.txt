A Pen created at CodePen.io. You can find this one at http://codepen.io/Shaz3e/pen/kwbxF.

 Slide Panel Open/Close onclick with jQuery