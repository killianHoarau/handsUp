$(document).ready(function(){
	var config = $('#dc-config-panel')
	$('#dc-config').click(function(event){
		event.preventDefault();
        event.stopPropagation();
		if (config.is(":visible")){
			config.slideUp(1000);
		}else{
			config.slideDown(1000);
		}
	});			
})